#include <stdio.h>
#include <stdlib.h>

int main()
{
	printf("Hello...\n");
	system("ls -l");

	return 0;
}

