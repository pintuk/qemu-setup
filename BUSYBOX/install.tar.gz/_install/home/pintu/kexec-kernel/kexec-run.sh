
#!/bin/sh
DUMPK_CMDLINE="console=ttyAMA0 root=/dev/ram rdinit=/sbin/init maxcpus=1 reset_devices"
kexec --type zImage \
-p ./zImage \
--initrd=./rootfs.img.gz \
--dtb=./vexpress-v2p-ca9.dtb \
--command-line="${DUMPK_CMDLINE}" 
[ $? -ne 0 ] && { 
    echo "kexec failed." ; exit 1
}
echo "$0: kexec: success, dump kernel loaded."
exit 0

