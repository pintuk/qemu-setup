
#!/bin/sh
# DUMPK_CMDLINE="console=ttyAMA0 root=/dev/ram rdinit=/sbin/init maxcpus=1 reset_devices"
DUMPK_CMDLINE="console=ttyAMA0 root=/dev/ram maxcpus=1 reset_devices"
./kexec-arm64 --type Image \
-p ./Image-capture-hana-5.4 \
--initrd=./initrd-arm64-sm8150.gz \
--command-line="${DUMPK_CMDLINE}" 
[ $? -ne 0 ] && { 
    echo "kexec failed." ; exit 1
}
echo "$0: kexec: success, dump kernel loaded."
exit 0

